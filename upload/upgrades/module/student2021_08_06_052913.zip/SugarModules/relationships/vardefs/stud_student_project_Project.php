<?php
// created: 2021-08-06 05:29:13
$dictionary["Project"]["fields"]["stud_student_project"] = array (
  'name' => 'stud_student_project',
  'type' => 'link',
  'relationship' => 'stud_student_project',
  'source' => 'non-db',
  'module' => 'stud_student',
  'bean_name' => 'stud_student',
  'vname' => 'LBL_STUD_STUDENT_PROJECT_FROM_STUD_STUDENT_TITLE',
);
