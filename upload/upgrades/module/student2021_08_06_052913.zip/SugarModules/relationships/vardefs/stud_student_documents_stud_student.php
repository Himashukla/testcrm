<?php
// created: 2021-08-06 05:29:13
$dictionary["stud_student"]["fields"]["stud_student_documents"] = array (
  'name' => 'stud_student_documents',
  'type' => 'link',
  'relationship' => 'stud_student_documents',
  'source' => 'non-db',
  'module' => 'Documents',
  'bean_name' => 'Document',
  'side' => 'right',
  'vname' => 'LBL_STUD_STUDENT_DOCUMENTS_FROM_DOCUMENTS_TITLE',
);
